Param
(
    [Parameter(Mandatory = $true)][ValidateSet("Start", "Stop")]
    [String]
    $Action,

    [Parameter(Mandatory = $true)]
    [String[]]
    $Subscriptions,

    [Bool]
    $DelayAutoStart = $false
)

$sub = Get-AzSubscription -ErrorAction SilentlyContinue

if(-not($sub))
{
	Connect-AzAccount -Identity -AccountId "REDACTED"
}

#Sine The automation account is using UTC we have to adjust the time to match our timezone.
$date = (get-date).AddHours(-4)

try {
    $dateStr = $date.ToString("yyyy-MM-dd");
    $todayHolidays = Invoke-WebRequest -UseBasicParsing "https://canada-holidays.ca/api/v1/holidays?year=$($date.Year)&federal=true&optional=false" `
    | Select-Object -ExpandProperty content `
    | ConvertFrom-Json `
    | Select-Object -ExpandProperty holidays `
    | Where-Object { $_.observedDate -eq $dateStr } `
    | Where-Object { $_.nameEn -notmatch "civic"} `
    | Where-Object { $_.observedDate -notmatch "-06-24"};
} catch {
    Write-Warning "Failed to find holidays";
    Write-Warning $_;
    $todayHolidays = @();
}

$shouldRun = $todayHolidays.Count -eq 0;

if ($shouldRun){

	    foreach ($Sub in $Subscriptions) {

            Write-Output "Set-AzContext $Sub"
            Set-azcontext -Subscription $Sub

            if ($Action -eq "Stop") {
                Write-Output "Stopping VMs";

                #https://github.com/Azure/azure-powershell/issues/9271
                $VMs = Get-azvm -status | Where-Object {$_.Tags["AutoShutDown"] -eq "Yes" -and $_.PowerState -eq "VM running" -and $_.Tags -notcontains "Vendor"}

                foreach ($VM in $VMs) {
                    Write-Output $VM.name
                    Stop-AzVM -force -Id $VM.Id -NoWait
                }
            }

            elseif ($Action -eq "Start") {

                if ($DelayAutoStart -eq $true) {
                    Write-Output "Starting Delayed VMs"
                    #https://github.com/Azure/azure-powershell/issues/9271
                    $VMs = Get-azvm -status | Where-Object {$_.Tags.Keys -contains "DelayAutoStart" -and $_.Tags["AutoStart"] -eq "Yes" -and $_.PowerState -eq "VM deallocated" -and $_.Tags -notcontains "Vendor"}
                }
                else {
                    Write-Output "Starting VMs";
                    $VMs = Get-azvm -status | Where-Object {$_.Tags.Keys -notcontains "DelayAutoStart" -and $_.Tags["AutoStart"] -eq "Yes" -and $_.PowerState -eq "VM deallocated" -and $_.Tags -notcontains "Vendor"}
                }

                foreach ($VM in $VMs) {
                    Write-Output $VM.name
                    Start-AzVM -Id $VM.Id -NoWait
                }

            }
    }
}
else {
    Write-Output "Script doesn't run on $($date.DayOfWeek)"
}

$date