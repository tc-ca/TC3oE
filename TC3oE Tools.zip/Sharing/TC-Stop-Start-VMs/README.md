# Stop-Start VM Automation
Running VMs 24h can become very expensive and it's not always needed in our non-prod subscriptions.
Using Azure policy, automation account, and some PowerShell we created a solution that will stop most of the Vms at 8pm and start a few of them back at 6am. 

By default, every VM will be shut down at 8PM and started at 6 AM but the owners have the option to modify this behavior by updating the tags that we automatically add to every VMs in these subscriptions. 

## Azure policy
Azure policy is used to add two tags to every VMs.

You can find it here: [Initiative Definition](https://portal.azure.com/#blade/Microsoft_Azure_Policy/PolicyMenuBlade/Definitions)



## Automation Account
We use an automation account to run and schedule the PowerShell script used to shut down and start the VMs every day. 

### Runbook
This is where is configured the PowerShell script inside of the Automation Account.
We use source control to sync the runbooks from an Azure DevOps **[repository](https://dev.azure.com/transport-canada/Azure%20Cloud%20Operations/_git/Runbooks?path=%2F&version=GBprod).**


### Schedules
Two schedules are created in both Automation account. **One at 6AM every day and one at 8PM every day.** 

## Powershell

This script was made to stop and start VMs using specific tags.

Two parameters are required.

* Action: This is a string where two options are possible (Start/Stop).
* Subscriptions: This is an array, it's used to declare which subscriptions are to be affected by the scripts.

## Exemption through the Self-Service-Portal
For some workload, we can't afford to shut down the VMs every day so it's important for us to have a solution in place to protect them from being turned off.

As an app owner if I want my workload to be exempted I can use the Self-Service-Portal to request an exemption to be created for a specific VM.

### MS Form
When users click on the link from the self-service portal they are redirected to an MS Form where they can submit the necessary information.

### Power Automate Flow
When a user submits a form, a flow from power automate receives it and proceeds to send a notification on teams to the list of approvers and to send an email to the requesting user. 

### Azure DevOps Pipeline
When a request is approved, the Power Automate Flow will trigger an Azure DevOps Pipeline. This pipeline runs a PowerShell script and this script will create a new Policy Exemption to allow the VM to not be restarted every day. 




