#App Service Templates

This folder contains all you need to spin up a new web app in azure using bicep.

You can use these interactively if this is what you prefer, but we strongly suggest that you create your own main.bicep file and reference our templates as a module.

Choose between one of the three flavours below.

For every parameters you can type "?" to get the instructions. 

## Container
Create a Linux App Service Plan and allows you to specific a docker image to run on it.

## Linux
Create a Linux App Service Plan and allows you to specific a runtime to run your code.

## Windows
Create a Windows App Service Plan and allows you to specific a runtime to run your code.

