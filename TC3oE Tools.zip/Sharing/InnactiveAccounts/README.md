# Introduction 

The primary objective of this solution is to establish an automated process that ensures the automatic disabling of user accounts that have remained inactive for a period of 90 days.

# Getting Started
## Software dependencies

### Code
* Visual Studio Code
* Python
* [Azure function core tools](https://docs.microsoft.com/en-us/azure/azure-functions/functions-run-local?tabs=v3%2Clinux%2Ccsharp%2Cportal%2Cbash%2Ckeda)

### Infra
* azure cli
* bicep
* powershell
  * Az Module
  * AzureAD Module

# Deployment Process

## Python

To update the Python script, you can conveniently push your modifications to the repository. Subsequently, the pipeline will handle the deployment of the updated script to the Azure function, ensuring a seamless update process. It is worth noting that all the essential services required to operate this solution have been deployed using Bicep.

## Bicep
This is how you can use Bicep to deploy the solution.
```bash
az login
az account set -s sced-core
az deployment sub create --template-file InactiveAccounts.bicep --location canadacentral --query properties.outputs.identity.value
```

## Powershell
If you ever need to redeploy the solution from scratch, you will have to allow the Azure function's managed identity to use Microsoft Graph API. This is done using the PowerShell script included in the repository. 
```Powershell
.\applyPermissions.ps1 -spID [Enter here the output bicep gave you]
```