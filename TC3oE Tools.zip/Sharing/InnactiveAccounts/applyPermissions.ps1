# Install the module. (You need admin on the machine.)
# Install-Module AzureAD.

param(
    # Get the ID of the managed identity for the web app.
     [Parameter()]
     [string]$spID

 )
 
connect-AzureAD

# Check the Microsoft Graph documentation for the permission you need for the operation.
$Permissions = @("User.ReadWrite.All", "AuditLog.Read.All", "GroupMember.Read.All")


# Get the service principal for Microsoft Graph.
# First result should be AppId 00000003-0000-0000-c000-000000000000
$GraphServicePrincipal = Get-AzureADServicePrincipal -SearchString "Microsoft Graph" | Select-Object -first 1

foreach ($permission in $Permissions) {
    # Assign permissions to the managed identity service principal.
    $AppRole = $GraphServicePrincipal.AppRoles | `
    Where-Object {$_.Value -eq $Permission -and $_.AllowedMemberTypes -contains "Application"}

    New-AzureAdServiceAppRoleAssignment -ObjectId $spID -PrincipalId $spID `
    -ResourceId $GraphServicePrincipal.ObjectId -Id $AppRole.Id
}
