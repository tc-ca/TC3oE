import http.client
import json
import urllib.parse
import requests


from azure.identity import DefaultAzureCredential

token = DefaultAzureCredential().get_token("00000003-0000-0000-c000-000000000000/.default").token


headers = {'Authorization': 'Bearer ' + token}

with open("Users/data-users.json") as file:
    users = json.load(file)

for user in users:
    print(user)
    response = requests.patch(f"https://graph.microsoft.com/v1.0/users/{user}", headers=headers,
        json={"accountEnabled": False})
    print(f"{response} {response.text}")