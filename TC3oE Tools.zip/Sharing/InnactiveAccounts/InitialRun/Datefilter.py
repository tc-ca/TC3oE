import json
import datetime
from dateutil import parser
from prettytable import PrettyTable


with open("Users/data-users.json") as file:
    data = json.load(file)


today = datetime.date.today()
days = datetime.timedelta(90)
date = today - days


x = PrettyTable()

x.field_names = ["userPrincipalName", "lastSignInDateTime"]


users = []

with open("/home/gabriel/InactiveAccounts/InactiveAccountsFunc/whitelist.json") as file:
    whitelist = json.load(file)


for user in data:
    if user not in whitelist:
        if data[user]["LastSignInDateTime"] != None:
            time = parser.parse(data[user]["LastSignInDateTime"])
            if date >= time.date():
                x.add_row([user,data[user]])
                users.append(user)
        else:
            time = parser.parse(data[user]["CreatedDateTime"])
            if date >= time.date():
                x.add_row([user,data[user]])
                users.append(user)

        

with open("Users/to-be-deleted-users.json", "w") as file:
    json.dump(users, file)

