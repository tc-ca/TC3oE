from genericpath import exists
import http.client
import json
import urllib.parse


from azure.identity import DefaultAzureCredential

token = DefaultAzureCredential().get_token("00000003-0000-0000-c000-000000000000/.default").token

# print(token)
i = 0

users = {}

headers = {'Authorization': 'Bearer ' + token}
conn = http.client.HTTPSConnection('graph.microsoft.com')
conn.request("GET", urllib.parse.quote(f"/beta/users?$select=signInActivity", safe="?/$&="), "", headers)
response = conn.getresponse()
data = response.read()
data = data.decode('utf-8')
data = json.loads(data)
print("page 0")
for user in data["value"]:
    try:
        if user["onPremisesDomainName"] == None and user["accountEnabled"] == True:
            if "signInActivity" in user and user["signInActivity"]["lastSignInDateTime"] != "0001-01-01T00:00:00Z":
                users[user["userPrincipalName"]] = {"CreatedDateTime" : user["createdDateTime"], "LastSignInDateTime" : user["signInActivity"]["lastSignInDateTime"]}
            else:
                users[user["userPrincipalName"]] = {"CreatedDateTime" : user["createdDateTime"], "LastSignInDateTime" : None}
    except:
        pass

# with open(f'Users/data-users-0.json', 'w') as outfile:
#     json.dump(users, outfile)



try: 
    while data["@odata.nextLink"] != None:
        i = i + 1
        headers = {'Authorization': 'Bearer ' + token}
        conn = http.client.HTTPSConnection('graph.microsoft.com')
        conn.request("GET", data["@odata.nextLink"], "", headers)
        response = conn.getresponse()
        data = response.read()
        data = data.decode('utf-8')
        data = json.loads(data)
        print(f"page {i}")
        for user in data["value"]:
            try:
                if user["onPremisesDomainName"] == None and user["accountEnabled"] == True and user["userType"] == "Guest":
                    if "signInActivity" in user and user["signInActivity"]["lastSignInDateTime"] != "0001-01-01T00:00:00Z":
                        users[user["userPrincipalName"]] = {"CreatedDateTime" : user["createdDateTime"], "LastSignInDateTime" : user["signInActivity"]["lastSignInDateTime"]}
                    else:
                        users[user["userPrincipalName"]] = {"CreatedDateTime" : user["createdDateTime"], "LastSignInDateTime" : None}
            except Exception as e:
                print(e)
except Exception as e:
    print(e)

with open(f'Users/data-users.json', 'w') as outfile:
    json.dump(users, outfile)
