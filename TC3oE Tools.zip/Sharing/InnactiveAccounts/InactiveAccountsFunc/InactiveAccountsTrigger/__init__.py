import datetime
import http.client
import json
import requests
import urllib.parse
import logging
from dateutil import parser

import azure.functions as func
from azure.identity import ChainedTokenCredential, ManagedIdentityCredential, DefaultAzureCredential

inactivity_days = 90 

today = datetime.date.today()
days = datetime.timedelta(inactivity_days)
date = today - days

def get_token():
    token = DefaultAzureCredential().get_token("00000003-0000-0000-c000-000000000000/.default").token
    # logging.info(token)
    return token

def get_graph(token, url):
    headers = {'Authorization': 'Bearer ' + token, 'ConsistencyLevel': 'eventual'}
    conn = http.client.HTTPSConnection('graph.microsoft.com')
    conn.request("GET", url, "", headers)
    response = conn.getresponse()
    data = response.read()
    data = data.decode('utf-8')
    data = json.loads(data)
    return data

def get_exempted_users(token):
    users_exempted = []
    url = "/v1.0/groups/0e757c6d-5d7d-4dd3-b056-89ce4b31df68/members"
    data = get_graph(token, url)

    for user in data["value"]:
        users_exempted.append(user["userPrincipalName"])
        
    logging.info("Exempted users received")
    return users_exempted

def get_all_users(token):
    users = []
    url = "/beta/users?$filter=onPremisesSyncEnabled eq null and accountEnabled eq true&$select=signInActivity&$count=true".replace(" ", "%20")
    data = get_graph(token, url)
    users.extend(data["value"])

    while "@odata.nextLink" in data:
        url = data["@odata.nextLink"]
        data = get_graph(token, url)
        users.extend(data["value"])
    logging.info("User list received")
    return users

def filter_unwanted_users(users, users_exempted):
    users_to_delete = []
    for user in users:
        if user["onPremisesDomainName"] == None and user["accountEnabled"] == True:
            if user["userPrincipalName"] not in users_exempted:
                if "signInActivity" in user and user["signInActivity"]["lastSignInDateTime"] != "0001-01-01T00:00:00Z":
                        last_login = parser.parse(user["signInActivity"]["lastSignInDateTime"])
                        if date >= last_login.date():
                            users_to_delete.append(user)
                else:
                    created_time = parser.parse(user["createdDateTime"])
                    if date >= created_time.date():
                        users_to_delete.append(user)
    logging.info("Unwanted user filtered")
    return users_to_delete

def desactivate_inactive_users(token, users):
    headers = {'Authorization': 'Bearer ' + token}
    for user in users:

        id = user["id"]
        response = requests.patch(f"https://graph.microsoft.com/v1.0/users/{id}", headers=headers,
            json={"accountEnabled": False})
        if response.status_code == 204:
            logging.info("User : " + user["userPrincipalName"] + " disabled")
        else:
            logging.warning(f"Failed to disable {user['userPrincipalName']}")
            repjson = response.json
            logging.warning(repjson)



def main(mytimer: func.TimerRequest) -> None:
    token = get_token()
    users_exempted = get_exempted_users(token)
    users = get_all_users(token)
    users_to_delete = filter_unwanted_users(users, users_exempted)

    # !!!!!!!! DANGER ZONE !!!!!!!!!
    desactivate_inactive_users(token, users_to_delete)
